package com.cg.bank.exceptions;

public class NoAccountFoundException extends Exception{

	public NoAccountFoundException()
	{
		super("The Account Number is not found");
	}

}
