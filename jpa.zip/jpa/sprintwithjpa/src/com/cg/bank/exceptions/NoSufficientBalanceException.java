package com.cg.bank.exceptions;

public class NoSufficientBalanceException extends Exception{

	public NoSufficientBalanceException() {
		super("The Sender Account Balance is not suffecient");
	}

}
