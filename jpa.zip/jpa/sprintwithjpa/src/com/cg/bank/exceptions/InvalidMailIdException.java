package com.cg.bank.exceptions;
public class InvalidMailIdException extends Exception {

	public InvalidMailIdException()
	{
		super("The Email Format submitted is Invalid");
	}

}
