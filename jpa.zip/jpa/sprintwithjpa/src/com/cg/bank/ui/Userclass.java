package com.cg.bank.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bank.model.Account;
import com.cg.bank.service.AccountService;
import com.cg.bank.service.AccountServiceImplementation;


public class Userclass {
	static AccountService service=new AccountServiceImplementation();
	
	public static void showStatements() {
		System.out.println("1. Create Account");
		System.out.println("2. Add Money");
		System.out.println("3. Show Account Details");
		System.out.println("4. Transfer Money");
		System.out.println("5. Show All Account Details");
		System.out.println("6. Exit");
		System.out.print("Enter your choice : ");
	}
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		int option;
		boolean res;
		while(true)
		{
			showStatements();
			
			option = sc.nextInt();
			switch(option)
			{
			case 1:
			
				System.out.println("Creating Account....");
				try
				{
					Account acc=new Account();
					System.out.println("Enter name:");
					acc.setName(sc.next());
					System.out.println("Enter mobile number:");
					acc.setMobileNumber(sc.nextLong());
					System.out.println("Enter emailId:");
					acc.setEmailId(sc.next());
					acc.setBalance(0);
					service.createAccount(acc);
				}
				catch(Exception e)
				{
//					System.out.println(e);
					e.printStackTrace();
				}
				break;
				
			case 2:
				
				System.out.println("Adding Money....");
				try {
					System.out.println("Enter account number to add money:");
					int accNumber=sc.nextInt();
					System.out.println("Enter the amount: "+accNumber);
					int Amount=sc.nextInt();
					res=service.addMoney(accNumber, Amount);
					if(res) {
						System.out.println("Money added successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
				
			case 3:
			
				System.out.println("View Account Details....");
				try
				{
					System.out.println("Enter Account Number");
					int AccountNumber=sc.nextInt();
					Account user=service.viewAccount(AccountNumber);
					System.out.println("Name="+user.getName()+"\nPhone="+user.getMobileNumber()+"\nEmail="+user.getEmailId()+"\nBalance="+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
				
			case 4:
				
				
				System.out.println("Transfering money....");
				try
				{
					System.out.println("Enter sender Account Number");
					int senderAccountNumber=sc.nextInt();
					System.out.println("Enter Reciever Account Number");
					int recieverAccountNumber=sc.nextInt();
					System.out.println("Enter the amount");
					int amount=sc.nextInt();
					res=service.transfer(senderAccountNumber, recieverAccountNumber, amount);
					if(res) {
						System.out.println("Money transfered successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
				
			case 5:
			
				
				System.out.println("All Accounts:\n");
				try
				{	
					List<Account> list=service.getAllAccounts();
					for (Account account : list) {
						System.out.println("Account Number: "+account.getAccNumber()+"\t\tName: "+account.getName());
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				service.closeFactory();
				System.exit(0);
			default:
				break;
			}
		}
	}

}
