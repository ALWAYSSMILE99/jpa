package com.cg.bank.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.exceptions.InvalidMailIdException;
import com.cg.bank.exceptions.InvalidMobileNumberException;
import com.cg.bank.model.Account;

public class Validator {

	public void validator(Account user) throws InvalidMailIdException,InvalidMobileNumberException
	{
		try {
			validatePhoneNumber(user.getMobileNumber());
			validateEmail(user.getEmailId());
			
		} catch (InvalidMobileNumberException | InvalidMailIdException e) {
			// TODO Auto-generated catch block
			throw e;
		}
	}

	public void validateEmail(String string) throws InvalidMailIdException
	{
	
			Pattern p = Pattern.compile("\\b[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\\b");
			Matcher m = p.matcher(string);
			if(!m.matches())
			{
				throw new InvalidMailIdException();
			}
	
	}

	public void validatePhoneNumber(long phone) throws InvalidMobileNumberException
	{
			String temp=String.valueOf(phone);
			Pattern p = Pattern.compile("\\d{10}");
			Matcher m = p.matcher(temp);
			if(!m.matches() || (!(temp.length()==10)))
			{
				throw new InvalidMobileNumberException();
			}
	}
	
}
