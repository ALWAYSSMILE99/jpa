package com.cg.bank.service;

import java.util.List;

import com.cg.bank.model.Account;


public interface AccountService {
	public void createAccount(Account user) throws Exception;
	public Account viewAccount(int accountNumber) throws Exception;
	public boolean addMoney(int accountNumber, int amount) throws Exception;
	public boolean transfer(int accountNumber1,int accountNumber2, int amount) throws Exception;
	public List<Account> getAllAccounts() throws Exception;
	void closeFactory();
}
